//: [Previous](@previous)
//: # Ignorar el error
//: Usar `try!` cuando no queremos gestionar el error porque es crítico y si se da no tiene sentido continuar con el programa
//: [Next](@next)
